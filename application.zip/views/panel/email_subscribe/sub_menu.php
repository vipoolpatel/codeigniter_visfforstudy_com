    <div class="os-tabs-w menu-shad">
          <div class="os-tabs-controls">
            
             <ul class="navs navs-tabs upper">
                 <li class="navs-item">
                    <a class="navs-links <?=($this->uri->segment(3) == 'email_subscribe_list') ? 'active' : '' ?>" href="<?=base_url()?>panel/emailsubscribe/email_subscribe_list">
                        <i class="picons-thin-icon-thin-0704_users_profile_group_couple_man_woman"></i>
                        <span>Email Subscribe List</span></a>
                 </li>
                
                
                

              </ul>
          </div>
        </div><br>