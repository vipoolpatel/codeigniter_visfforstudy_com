


<body class="menu-position-side menu-side-left full-screen with-content-panel">
  <div class="with-side-panel">
    <div class="layout-w">




<!-- start slide menu icon-->
      <div class="fixed-sidebar">
    <div class="fixed-sidebar-left sidebar--small" id="sidebar-left">
      <a href="<?=base_url()?>panel/dashboard" class="logo">
        <div class="img-wrap">
          <img src="<?=base_url()?>backed/uploads/logoicon.png">
        </div>
      </a>

      <div class="mCustomScrollbar" data-mcs-theme="dark">
        <ul class="left-menu">
          <li>
            <a href="#" class="js-sidebar-open">
              <i class="left-menu-icon picons-thin-icon-thin-0069a_menu_hambuger"></i>
            </a>
          </li>
          <li>
              <a href="<?=base_url()?>panel/dashboard" data-toggle="tooltip" data-placement="right" data-original-title="Dashboard">
                  <div class="left-menu-icon">
                      <i class="picons-thin-icon-thin-0045_home_house"></i>
                  </div>
              </a>
          </li>
          <li>
            <a href="<?=base_url()?>panel/user" data-toggle="tooltip" data-placement="right" data-original-title="Users">
                <div class="left-menu-icon">        
                  <i class="picons-thin-icon-thin-0704_users_profile_group_couple_man_woman"></i>
                </div>
            </a>
          </li>

          <li>
            <a href="<?=base_url()?>panel/category" data-toggle="tooltip" data-placement="right" data-original-title="Category">
                <div class="left-menu-icon">        
                  <i class="picons-thin-icon-thin-0389_gavel_hammer_law_judge_court"></i>
                </div>
            </a>
          </li>

          <li>
            <a href="<?=base_url()?>panel/course" data-toggle="tooltip" data-placement="right" data-original-title="Course">
                <div class="left-menu-icon">        
                  <i class="os-icon picons-thin-icon-thin-0017_office_archive"></i>
                </div>
            </a>
          </li>

            

             <li>
              <a href="<?=base_url()?>panel/demands" data-toggle="tooltip" data-placement="right" data-original-title="demand">
                <div class="left-menu-icon">
                  <i class="os-icon picons-thin-icon-thin-0010_newspaper_reading_news"></i>
                </div>
              </a>
            </li>


             <li>
              <a href="<?=base_url()?>panel/offer" data-toggle="tooltip" data-placement="right" data-original-title="Offer">
                <div class="left-menu-icon">
                  <i class="picons-thin-icon-thin-0378_analytics_presentation_statistics_graph"></i>
                </div>
              </a>
            </li>

             <li>
                <a href="<?=base_url()?>panel/bookcourse/book_course_list" data-toggle="tooltip" data-placement="right" data-original-title="Book Course">
                    <div class="left-menu-icon">
                        <i class="os-icon picons-thin-icon-thin-0006_book_writing_reading_read_manual"></i>
                    </div>
                </a>
            </li>
            <li>
                <a href="<?=base_url()?>panel/acceptedoffer" data-toggle="tooltip" data-placement="right" data-original-title="Accepted Offer">
                    <div class="left-menu-icon">
                        <i class="picons-thin-icon-thin-0378_analytics_presentation_statistics_graph"></i>
                    </div>
                </a>
            </li>

            <li>
              <a href="<?=base_url()?>panel/notification" data-toggle="tooltip" data-placement="right" data-original-title="Notifications">
                <div class="left-menu-icon">
                  <i class="picons-thin-icon-thin-0286_mobile_message_sms"></i>
                </div>
              </a>
            </li>

            <li>
                <a href="<?=base_url()?>panel/chat" data-toggle="tooltip" data-placement="right" data-original-title="Chat">
                    <div class="left-menu-icon">
                        <i class="picons-thin-icon-thin-0378_analytics_presentation_statistics_graph"></i>
                    </div>
                </a>
            </li>

             <li>
              <a href="<?=base_url()?>panel/calendar" data-toggle="tooltip" data-placement="right" data-original-title="Calendar">
                <div class="left-menu-icon">
                  <i class="picons-thin-icon-thin-0021_calendar_month_day_planner"></i>
                </div>
              </a>
            </li>

             <li>
              <a href="<?=base_url()?>panel/emailsubscribe" data-toggle="tooltip" data-placement="right" data-original-title="Email Subscribe">
                <div class="left-menu-icon">
                  <i class="os-icon picons-thin-icon-thin-0006_book_writing_reading_read_manual"></i>
                </div>
              </a>
            </li>

            <li>
              <a href="<?=base_url()?>panel/emailmarketing" data-toggle="tooltip" data-placement="right" data-original-title="Email Marketing">
                <div class="left-menu-icon">
                  <i class="os-icon picons-thin-icon-thin-0006_book_writing_reading_read_manual"></i>
                </div>
              </a>
            </li>

            <li>
              <a href="<?=base_url()?>panel/setting" data-toggle="tooltip" data-placement="right" data-original-title="Setting">
                <div class="left-menu-icon">
                  <i class="picons-thin-icon-thin-0051_settings_gear_preferences"></i>
                </div>
              </a>
            </li>
<!-- 
          <li>
              <a href="academic.html" data-toggle="tooltip" data-placement="right" data-original-title="Academic">
                <div class="left-menu-icon">
                  <i class="picons-thin-icon-thin-0680_pencil_ruller_drawing"></i>
                </div>
              </a>
            </li>  -->
             
         </ul>
      </div>
    </div>

<!-- END slide menu icon -->


<!-- start slide menu  -->

    <div class="fixed-sidebar-left sidebar--large" id="sidebar-left-1">
        <a href="<?=base_url()?>panel/dashboard" class="logo">
          <div class="img-wrap">
            <img src="<?=base_url();?>backed/uploads/logoicon.png">
          </div>
          <div class="title-block">
            <h6 class="logo-title">VISFFOROOM</h6>
          </div>
        </a>
        <div class="mCustomScrollbar" data-mcs-theme="dark">
          <ul class="left-menu">
            <li>
              <a href="#" class="js-sidebar-open">
                <i class="left-menu-icon picons-thin-icon-thin-0069a_menu_hambuger"></i>
                <span class="left-menu-title">Minimize menu</span>
              </a>
            </li>
            <li>
              <a href="<?=base_url()?>panel/dashboard">
                <div class="left-menu-icon">
                  <i class="picons-thin-icon-thin-0045_home_house"></i>
                </div>
                <span class="left-menu-title">Dashboard</span>
            </a>
            </li>

             <li>
              <a href="<?=base_url()?>panel/user">
                  <div class="left-menu-icon">        
                    <i class="picons-thin-icon-thin-0704_users_profile_group_couple_man_woman"></i>
                  </div>
                  <span class="left-menu-title">Users</span>
              </a>
             </li>

             <li>
              <a href="<?=base_url()?>panel/category">
                  <div class="left-menu-icon">        
                    <i class="picons-thin-icon-thin-0389_gavel_hammer_law_judge_court"></i>
                  </div>
                  <span class="left-menu-title">Category</span>
              </a>
             </li>

              <li>
              <a href="<?=base_url()?>panel/course">
                  <div class="left-menu-icon">        
                    <i class="os-icon picons-thin-icon-thin-0017_office_archive"></i>
                  </div>
                  <span class="left-menu-title">Course</span>
              </a>
             </li>

              

                <li>
                  <a href="<?=base_url()?>panel/demands">
                    <div class="left-menu-icon">
                      <i class="os-icon picons-thin-icon-thin-0010_newspaper_reading_news"></i>
                    </div>
                    <span class="left-menu-title">Demand</span>
                  </a>
                </li>

                <li>
                  <a href="<?=base_url()?>panel/offer">
                    <div class="left-menu-icon">
                      <i class="picons-thin-icon-thin-0378_analytics_presentation_statistics_graph"></i>
                    </div>
                    <span class="left-menu-title">Offer</span>
                  </a>
                </li>


                <li>
                  <a href="<?=base_url()?>panel/bookcourse/book_course_list">
                    <div class="left-menu-icon">
                      <i class="os-icon picons-thin-icon-thin-0006_book_writing_reading_read_manual"></i>
                    </div>
                    <span class="left-menu-title">Book Course</span>
                  </a>
                </li>

                 <li>
                  <a href="<?=base_url()?>panel/acceptedoffer">
                    <div class="left-menu-icon">
                      <i class="picons-thin-icon-thin-0378_analytics_presentation_statistics_graph"></i>
                    </div>
                    <span class="left-menu-title">Accepted Offer</span>
                  </a>
                </li>



                <li>
                  <a href="<?=base_url()?>panel/notification">
                    <div class="left-menu-icon">
                      <i class="picons-thin-icon-thin-0286_mobile_message_sms"></i>
                    </div>
                    <span class="left-menu-title">Notifications</span>
                  </a>
                </li>

                  <li>
                  <a href="<?=base_url()?>panel/chat">
                      <div class="left-menu-icon">
                        <i class="picons-thin-icon-thin-0378_analytics_presentation_statistics_graph"></i>
                      </div>
                      <span class="left-menu-title">Chat</span>
                  </a>
                </li>

              <li>
                  <a href="<?=base_url()?>panel/calendar">
                    <div class="left-menu-icon">
                      <i class="picons-thin-icon-thin-0021_calendar_month_day_planner"></i>
                    </div>
                    <span class="left-menu-title">Calendar</span>
                  </a>
                </li>

                <li>
                  <a href="<?=base_url()?>panel/emailsubscribe">
                    <div class="left-menu-icon">
                      <i class="os-icon picons-thin-icon-thin-0006_book_writing_reading_read_manual"></i>
                    </div>
                    <span class="left-menu-title">Email Subscribe</span>
                  </a>
                </li>
                <li>
                  <a href="<?=base_url()?>panel/emailmarketing">
                    <div class="left-menu-icon">
                      <i class="os-icon picons-thin-icon-thin-0006_book_writing_reading_read_manual"></i>
                    </div>
                    <span class="left-menu-title">Email Marketing</span>
                  </a>
                </li>
                <li>
                  <a href="<?=base_url()?>panel/setting">
                    <div class="left-menu-icon">
                      <i class="picons-thin-icon-thin-0051_settings_gear_preferences"></i>
                    </div>
                    <span class="left-menu-title">Setting</span>
                  </a>
                </li>



      <!--      <li>
                <a href="academic.html">
                  <div class="left-menu-icon">
                    <i class="picons-thin-icon-thin-0680_pencil_ruller_drawing"></i>
                  </div>
                  <span class="left-menu-title">Academic</span>
                </a>
              </li> -->  

            <br><br>
            <li></li>
          </ul>
        </div>
      </div>
    </div>

    <!-- end side menu -->

    <!-- start side menu -->

    <div class="fixed-sidebar fixed-sidebar-responsive">
      <div class="fixed-sidebar-left sidebar--small" id="sidebar-left-responsive">
        <a href="<?=base_url()?>panel/dashboard" class="logo js-sidebar-open">
          <img src="<?=base_url()?>backed/uploads/logoicon.png">
        </a>
      </div>
      <div class="fixed-sidebar-left sidebar--large" id="sidebar-left-1-responsive">
        <a href="<?=base_url()?>panel/dashboard" class="logo">
          <div class="img-wrap">
            <img src="<?=base_url()?>backed/uploads/logoicon.png">
          </div>
          <div class="title-block">
            <h6 class="logo-title">VISFFOROOM</h6>
          </div>
        </a>
        <div class="mCustomScrollbar" data-mcs-theme="dark">
          <ul class="left-menu">
            <li>
              <a href="#" class="js-sidebar-open">
                <i class="left-menu-icon picons-thin-icon-thin-0069a_menu_hambuger"></i>
                <span class="left-menu-title">Minimize menu</span>
              </a>
            </li>
            <li>
              <a href="<?=base_url()?>panel/dashboard">
                  <div class="left-menu-icon">
                    <i class="picons-thin-icon-thin-0045_home_house"></i>
                  </div>
                  <span class="left-menu-title">Dashboard</span>
              </a>
            </li>

            <li>
              <a href="<?=base_url()?>panel/user">
                <div class="left-menu-icon">        
                  <i class="picons-thin-icon-thin-0704_users_profile_group_couple_man_woman"></i>
                </div>
                <span class="left-menu-title">Users</span>
              </a>
             </li>
             <li>
              <a href="<?=base_url()?>panel/category">
                <div class="left-menu-icon">        
                  <i class="picons-thin-icon-thin-0389_gavel_hammer_law_judge_court"></i>
                </div>
                <span class="left-menu-title">Category</span>
              </a>
            </li>

              <li>
              <a href="<?=base_url()?>panel/course">
                <div class="left-menu-icon">        
                  <i class="os-icon picons-thin-icon-thin-0017_office_archive"></i>
                </div>
                <span class="left-menu-title">Course</span>
              </a>
            </li>


                <li>
                  <a href="<?=base_url()?>panel/demands">
                    <div class="left-menu-icon">
                      <i class="os-icon picons-thin-icon-thin-0010_newspaper_reading_news"></i>
                    </div>
                    <span class="left-menu-title">Demand</span>
                  </a>
                </li>

                <li>
                  <a href="<?=base_url()?>panel/offer">
                    <div class="left-menu-icon">
                      <i class="picons-thin-icon-thin-0378_analytics_presentation_statistics_graph"></i>
                    </div>
                    <span class="left-menu-title">Offer</span>
                  </a>
                </li>

                 <li>
                  <a href="<?=base_url()?>panel/bookcourse/book_course_list">
                    <div class="left-menu-icon">
                      <i class="os-icon picons-thin-icon-thin-0006_book_writing_reading_read_manual"></i>
                    </div>
                    <span class="left-menu-title">Book Course</span>
                  </a>
                </li>

                  <li>
                  <a href="<?=base_url()?>panel/acceptedoffer">
                    <div class="left-menu-icon">
                      <i class="picons-thin-icon-thin-0378_analytics_presentation_statistics_graph"></i>
                    </div>
                    <span class="left-menu-title">Accepted Offer</span>
                  </a>
                </li>


                 <li>
                    <a href="<?=base_url()?>panel/notification">
                      <div class="left-menu-icon">
                        <i class="picons-thin-icon-thin-0286_mobile_message_sms"></i>
                      </div>
                      <span class="left-menu-title">Notifications</span>
                    </a>
                  </li>

                  
                  <li>
                  <a href="<?=base_url()?>panel/chat">
                      <div class="left-menu-icon">
                        <i class="picons-thin-icon-thin-0378_analytics_presentation_statistics_graph"></i>
                      </div>
                      <span class="left-menu-title">Chat</span>
                  </a>
                </li>

                 <li>
                  <a href="<?=base_url()?>panel/calendar">
                    <div class="left-menu-icon">
                      <i class="picons-thin-icon-thin-0021_calendar_month_day_planner"></i>
                    </div>
                    <span class="left-menu-title">Calendar</span>
                  </a>
                </li>
                <li>
                  <a href="<?=base_url()?>panel/emailsubscribe">
                    <div class="left-menu-icon">
                      <i class="os-icon picons-thin-icon-thin-0006_book_writing_reading_read_manual"></i>
                    </div>
                    <span class="left-menu-title">Email Subscribe</span>
                  </a>
                </li>
                 <li>
                  <a href="<?=base_url()?>panel/emailmarketing">
                    <div class="left-menu-icon">
                      <i class="os-icon picons-thin-icon-thin-0006_book_writing_reading_read_manual"></i>
                    </div>
                    <span class="left-menu-title">Email Marketing</span>
                  </a>
                </li>
                 <li>
                  <a href="<?=base_url()?>panel/setting">
                    <div class="left-menu-icon">
                      <i class="picons-thin-icon-thin-0051_settings_gear_preferences"></i>
                    </div>
                    <span class="left-menu-title">Setting</span>
                  </a>
                </li>

          <!--   <li>
                <a href="academic.html">
                  <div class="left-menu-icon">
                    <i class="picons-thin-icon-thin-0680_pencil_ruller_drawing"></i>
                  </div>
                  <span class="left-menu-title">Academic</span>
                </a>
              </li>  -->
            
              <br><br>
            <li></li>
          </ul>
        </div>
      </div>
    </div>  

        <!-- end side menu -->
  



 <div class="content-w"> 
  <header class="header" id="site-header">
    
        
        <div class="header-content-wrapper"  style="padding-left: 85px;" >
<!-- 
        <form action="" class="search-bar w-search notification-list friend-requests"  method="post" accept-charset="utf-8">
            <div class="form-group with-button">
                <input class="form-control js-user-se arch" placeholder="Search students..." type="text" value="" name="search_key" required>
                <button type="submit"><i class="picons-thin-icon-thin-0033_search_find_zoom"></i></button>
            </div>
        </form>     -->


        <div class="control-block">
           <!--  <div class="control-icon more has-items">
                <i class="picons-thin-icon-thin-0275_chat_message_comment_bubble_typing"></i>
                   <div class="more-dropdown more-with-triangle triangle-top-center">
                    <div class="mCustomScrollbar" data-mcs-theme="dark">
                        <ul class="notification-list chat-message">
                            <li class="message-unread">
                                <div class="author-thumb">
                                    <img src="<?=base_url()?>backed/uploads/user.jpg" width="35px">
                                </div>
                                <div class="notification-event">
                                    <a href="#" class="h6 notification-friend">Harry Paul</a>
                                    <span class="chat-message-item" style="text-align: justify;">You: hi......</span>
                                    <span class="notification-date"><time class="entry-date updated">21 May. 04:45AM</time></span>
                                </div>
                            </li>
                        </ul>
                    </div> 
                    <a href="#" class="view-all bg-info">View all messages</a>
                </div>
            </div> -->

<?php 
  $row1headernotification = $this->db->select('offer_send.*,users.first_name,users.last_name');
  $row1headernotification = $this->db->from('offer_send');
  $row1headernotification = $this->db->join('users','users.id = offer_send.user_id');
  $row1headernotification = $this->db->where('offer_send.is_notification', '2');
  $row1headernotification = $this->db->get()->result();


  $row1course_notification = $this->db->select('course.*,users.first_name,users.last_name');
  $row1course_notification = $this->db->from('course');
  $row1course_notification = $this->db->join('users','users.id = course.user_id');
  $row1course_notification = $this->db->where('course.is_notification', '2');
  $row1course_notification = $this->db->get()->result();


  $row1demands_notification = $this->db->select('demands.*,users.first_name,users.last_name');
  $row1demands_notification = $this->db->from('demands');
  $row1demands_notification = $this->db->join('users','users.id = demands.user_id');
  $row1demands_notification = $this->db->where('demands.is_notification', '2');
  $row1demands_notification = $this->db->get()->result();

  
   $count_notification = count($row1headernotification) + count($row1course_notification) + count($row1demands_notification);
?>


            <div class="control-icon more has-items">
                <i class="picons-thin-icon-thin-0543_world_earth_worldwide_location_travel"></i>
                <?php if ($count_notification > 0) { ?>
                 <div class="label-avatar bg-success"> <?=$count_notification?></div>
                <?php } ?> 
                <div class="more-dropdown more-with-triangle triangle-top-center" style="padding: 0px">
                    <div class="mCustomScrollbar" data-mcs-theme="dark">
                        <ul class="notification-list">

                           <?php 
                           if(!empty($row1headernotification)) {
                           foreach($row1headernotification as $value1) { ?>

                            <li>
                                <div class="author-thumb">
                                    <img alt="" src="<?=base_url()?>backed/uploads/notify.svg" width="35px">
                                </div>
                                <div class="notification-event">
                                  <div>
                                    <a href="<?=base_url()?>panel/offer/view_offer/<?=$value1->id?>" class="h6 notification-friend"> <strong><?=$value1->first_name?> <?=$value1->last_name?></strong> created new offer</a>
                                  </div>
                                  <span class="notification-date"><time class="entry-date updated"><?=date('d-m-Y', strtotime($value1->created_date));?> at <?=date('h:i a', strtotime($value1->created_date));?></time></span>
                                </div>
                            </li>

                          <?php } } ?>


                          <?php 
                           if(!empty($row1course_notification)) {
                           foreach($row1course_notification as $value2) { ?>

                            <li>
                                <div class="author-thumb">
                                    <img alt="" src="<?=base_url()?>backed/uploads/notify.svg" width="35px">
                                </div>
                                <div class="notification-event">
                                  <div>
                                    <a href="<?=base_url()?>panel/course/view_course/<?=$value2->id?>" class="h6 notification-friend"> <strong><?=$value2->first_name?> <?=$value2->last_name?></strong> created new course</a>
                                  </div>
                                  <span class="notification-date"><time class="entry-date updated"><?=date('d-m-Y', strtotime($value2->created_date));?> at <?=date('h:i a', strtotime($value2->created_date));?></time></span>
                                </div>
                            </li>

                          <?php } } ?>


                          <?php 
                           if(!empty($row1demands_notification)) {
                           foreach($row1demands_notification as $value3) { ?>

                            <li>
                                <div class="author-thumb">
                                    <img src="<?=base_url()?>backed/uploads/notify.svg" width="35px">
                                </div>
                                <div class="notification-event">
                                  <div>
                                    <a href="<?=base_url()?>panel/demands/view_demands/<?=$value3->id?>" class="h6 notification-friend"> <?=$value3->first_name?> <?=$value3->last_name?> created new demand</a>
                                  </div>
                                  <span class="notification-date"><time class="entry-date updated"><?=date('d-m-Y h:i a', strtotime($value3->created_date));?></time></span>
                                </div>
                            </li>

                          <?php } } ?>

                            
                        </ul>
                    </div>
                    
                </div>
            </div>


       <?php

                $rows = $this->db->where('id', $this->session->userdata('user_id'));
                $rows = $this->db->where('is_admin', $this->session->userdata('user_is_admin'));
                $rows = $this->db->get('users')->row();

            ?>


            <div class="author-page author vcard inline-items more">
                <div class="author-thumb">
                   <?php

                        $datas = 'backed/uploads/profile/'.$rows->profile_pic;
                        if (file_exists($datas) && !empty($rows->profile_pic)) {
                        ?>
                  <img alt="author" src="<?=base_url()?>backed/uploads/profile/<?=$rows->profile_pic?>" class="avatar bg-white" width="32px">
                    <?php } else { ?>
                      <img alt="author" src="<?=base_url()?>backed/uploads/user.jpg" class="avatar bg-white" width="32px">
                     <?php  } ?>
                          
                    <div class="more-dropdown more-with-triangle">
                        <div class="mCustomScrollbar" data-mcs-theme="dark">
                            <ul class="account-settings">

                                <li>
                                    <a href="<?=base_url()?>panel/myaccount">
                                        <i class="picons-thin-icon-thin-0699_user_profile_avatar_man_male"></i>
                                        <span>My Account</span>
                                    </a>
                                </li>

                                <li>
                                    <a href="<?=base_url()?>logout">
                                        <i class="picons-thin-icon-thin-0040_exit_logout_door_emergency_outside"></i>
                                        <span>Logout</span>
                                    </a>
                                </li>

                            </ul>
                        </div>
                    </div>
                </div>
                <a href="#" class="author-name fn">
                    <div class="author-title">
                        <?=$rows->first_name?> <?=$rows->last_name?> <svg class="olymp-dropdown-arrow-icon"><use xlink:href="style/olapp/svg-icons/sprites/icons.svg#olymp-dropdown-arrow-icon"></use></svg>
                    </div>
                    <?php
                    if($this->session->userdata('user_is_admin') == 4)
                    {
                    ?>
                    <span class="author-subtitle">Super Admin</span>
                  <?php }
                  else
                  { ?>
                  <span class="author-subtitle">Admin</span>
                 <?php }
                  ?>
                </a>
            </div>
        </div>
  </div>
</header>









<!-- mobile view start -->

<header class="header header-responsive" id="site-header-responsive">
    <div class="header-content-wrapper">
        <ul class="nav nav-tabs mobile-app-tabs" role="tablist">
    
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#notification" role="tab">
                    <div class="control-icon has-items">
                        <i class="picons-thin-icon-thin-0543_world_earth_worldwide_location_travel"></i>
                       <?php if ($count_notification > 0) { ?>
                         <div class="label-avatar bg-success"> <?=$count_notification?></div>
                        <?php } ?> 
                                  
                    </div>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#autor" role="tab">
                    <div class="author-page author vcard inline-items more " style="margin-top:-16px">
                      <div class="author-thumb imgs">
                        <img alt="author" src="<?=base_url();?>backed/uploads/user.jpg" class="avatar bg-white" width="35px">
                    </div>  
                  </div>
                </a>
            </li>
        </ul>
    </div>
    <div class="tab-content tab-content-responsive">

        <div class="tab-pane " id="notification" role="tabpanel">
            <div class="mCustomScrollbar" data-mcs-theme="dark">
                <ul class="notification-list">
                    <li>

                      <?php 
                           if(!empty($row1headernotification)) {
                           foreach($row1headernotification as $value1) { ?>

                            <li>
                                <div class="author-thumb">
                                    <img alt="" src="<?=base_url()?>backed/uploads/notify.svg" width="35px">
                                </div>
                                <div class="notification-event">
                                  <div>
                                    <a href="<?=base_url()?>panel/offer/view_offer/<?=$value1->id?>" class="h6 notification-friend"> <strong><?=$value1->first_name?> <?=$value1->last_name?></strong> has sent offer</a>
                                  </div>
                                  <span class="notification-date"><time class="entry-date updated"><?=date('d-m-Y', strtotime($value1->created_date));?> at <?=date('h:i a', strtotime($value1->created_date));?></time></span>
                                </div>
                            </li>

                          <?php } } ?>


                             <?php 
                           if(!empty($row1course_notification)) {
                           foreach($row1course_notification as $value2) { ?>

                            <li>
                                <div class="author-thumb">
                                    <img alt="" src="<?=base_url()?>backed/uploads/notify.svg" width="35px">
                                </div>
                                <div class="notification-event">
                                  <div>
                                    <a href="<?=base_url()?>panel/course/view_course/<?=$value2->id?>" class="h6 notification-friend"> <strong><?=$value2->first_name?> <?=$value2->last_name?></strong> has course added</a>
                                  </div>
                                  <span class="notification-date"><time class="entry-date updated"><?=date('d-m-Y', strtotime($value2->created_date));?> at <?=date('h:i a', strtotime($value2->created_date));?></time></span>
                                </div>
                            </li>

                          <?php } } ?>


                          <?php 
                           if(!empty($row1demands_notification)) {
                           foreach($row1demands_notification as $value3) { ?>

                            <li>
                                <div class="author-thumb">
                                    <img alt="" src="<?=base_url()?>backed/uploads/notify.svg" width="35px">
                                </div>
                                <div class="notification-event">
                                  <div>
                                    <a href="<?=base_url()?>panel/demands/view_demands/<?=$value3->id?>" class="h6 notification-friend"> <strong><?=$value3->first_name?> <?=$value3->last_name?></strong> has Demand added</a>
                                  </div>
                                  <span class="notification-date"><time class="entry-date updated"><?=date('d-m-Y', strtotime($value3->created_date));?> at <?=date('h:i a', strtotime($value3->created_date));?></time></span>
                                </div>
                            </li>

                          <?php } } ?>
                         
                    </li>
                </ul>
            </div>
        </div>



        <div class="tab-pane " id="autor" role="tabpanel">
                <div class="mCustomScrollbar" data-mcs-theme="dark">
                    <ul class="account-settings">
                        <li>
                            <a href="<?=base_url()?>panel/myaccount">
                                <i class="picons-thin-icon-thin-0699_user_profile_avatar_man_male"></i>
                                <span>My profile</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?=base_url()?>logout">
                                <i class="picons-thin-icon-thin-0040_exit_logout_door_emergency_outside"></i>
                                <span>Logout</span>
                            </a>
                        </li>
                    </ul>
                </div>
          </div>
      </div>
</header> 