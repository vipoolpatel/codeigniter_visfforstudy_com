 <p>Hi <?=$subject?></p>

 <p><?=$body?></p>
                           
