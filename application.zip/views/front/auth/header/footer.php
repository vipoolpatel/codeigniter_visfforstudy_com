	
	<!--vendor js-->
    <script src="<?=base_url();?>assets/js/vendor.js"></script>
	<!--custom js-->
	<script src="<?=base_url();?>assets/js/main.js"></script>
</body>
</html>