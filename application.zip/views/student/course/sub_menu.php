<div class="os-tabs-w menu-shad">
          <div class="os-tabs-controls">
            <ul class="navs navs-tabs upper">
              <li class="navs-item">
                <a class="navs-links active" href="<?=base_url()?>student/course"><i class="os-icon picons-thin-icon-thin-0017_office_archive"></i><span>Course List</span></a>
              </li>
             
            </ul>
          </div>
        </div>
        <br>