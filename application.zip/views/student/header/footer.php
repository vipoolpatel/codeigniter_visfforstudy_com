    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.bundle.js"></script> -->

<style>
    .datepicker{z-index:1151 !important;}
</style>      
   <!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
    <script src="<?=base_url();?>backed/js/jquery.min.js"></script> 
    
    <script src="<?=base_url()?>backed/style/js/picker.js"></script>
    <script src="<?=base_url()?>backed/style/js/picker.en.js"></script>
    <script src="<?=base_url()?>backed/style/cms/bower_components/bootstrap-clockpicker/bootstrap-clockpicker.min.js"></script>
    <script type="text/javascript">
        $('.clockpicker').clockpicker({
            placement: 'top',
            align: 'left',
            donetext: 'Done'
        });

         $('.datepickerdata').datepicker({
          'dateFormat' : "dd-mm-yyyy"
        });
           
    </script>

    <script src="<?=base_url()?>backed/style/cms/bower_components/jquery/dist/jquery.min.js"></script>
    <script src='<?=base_url()?>backed/style/fullcalendar/js/jquery.js'></script>
    <script src="<?=base_url()?>backed/style/cms/bower_components/moment/moment.js"></script>
    <script src="<?=base_url()?>backed/style/cms/bower_components/tether/dist/js/tether.min.js"></script>
    <!-- <script src="<?=base_url()?>backed/style/cms/bower_components/ckeditor/ckeditor.js"></script> -->
    <script src="<?=base_url()?>backed/style/cms/bower_components/bootstrap-validator/dist/validator.min.js"></script>
    <script src="<?=base_url()?>backed/style/cms/bower_components/dropzone/dist/dropzone.js"></script>
    <script src="<?=base_url()?>backed/style/cms/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?=base_url()?>backed/style/cms/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?=base_url()?>backed/style/cms/bower_components/perfect-scrollbar/js/perfect-scrollbar.jquery.min.js"></script>
    <script src="<?=base_url()?>backed/style/cms/bower_components/bootstrap/js/dist/util.js"></script>
    <script src="<?=base_url()?>backed/style/cms/bower_components/bootstrap/js/dist/tab.js"></script>
    <script src="<?=base_url()?>backed/style/cms/js/main.js"></script>
    <script src="<?=base_url()?>backed/style/cms/bower_components/dragula.js/dist/dragula.min.js"></script>
    <script src="<?=base_url()?>backed/style/cms/bower_components/bootstrap/js/dist/modal.js"></script>
    <!-- <script src="<?=base_url()?>backed/style/cms/bower_components/bootstrap/js/dist/tooltip.js"></script> -->
    <script src="<?=base_url()?>backed/https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="<?=base_url()?>backed/style/cms/js/dataTables.bootstrap4.min.js"></script>
    <!-- <script src="<?=base_url()?>backed/style/tinymce/tinymce.min.js"></script> -->
    <script src="<?=base_url()?>backed/style/cms/bower_components/popper.js/dist/umd/popper.min.js"></script>
    <script src="<?=base_url()?>backed/style/cms/bower_components/slick-carousel/slick/slick.min.js"></script>
    <script src="<?=base_url()?>backed/style/cms/bower_components/bootstrap/js/dist/alert.js"></script>
    <script src="<?=base_url()?>backed/style/cms/bower_components/bootstrap/js/dist/button.js"></script>
    <script src="<?=base_url()?>backed/style/cms/bower_components/bootstrap/js/dist/carousel.js"></script>
    <script src="<?=base_url()?>backed/style/cms/bower_components/bootstrap/js/dist/collapse.js"></script>
    <script src="<?=base_url()?>backed/style/cms/bower_components/bootstrap/js/dist/dropdown.js"></script>
    <script src="<?=base_url()?>backed/assets/js/ajax-form-submission.js"></script>
    <script src='<?=base_url()?>backed/style/fullcalendar/js/fullcalendar.min.js'></script>
    <script src="<?=base_url()?>backed/style/olapp/js/jquery.appear.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/jquery.matchHeight.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/svgxuse.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/Headroom.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/velocity.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/ScrollMagic.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/jquery.waypoints.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/jquery.countTo.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/material.min.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/bootstrap-select.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/smooth-scroll.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/selectize.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/swiper.jquery.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/moment.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/isotope.pkgd.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/circle-progress.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/loader.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/jquery.magnific-popup.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/sticky-sidebar.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/js/base-init.js"></script>
    <script defer src="<?=base_url()?>backed/style/olapp/fonts/fontawesome-all.js"></script>
    <script src="<?=base_url()?>backed/style/olapp/Bootstrap/dist/js/bootstrap.bundle.js"></script> 

<script src="<?=base_url()?>backed/editor/summernote-bs4.min.js"></script>
<script src="<?=base_url()?>backed/editor/demo.summernote.js"></script>

<script type="text/javascript">
    $('.summernoteeditor').summernote({
       toolbar: [
          ['style', ['style']],
          ['font', ['bold', 'italic', 'underline', 'clear']],
          ['fontname', ['fontname', 'color']],
          ['para', ['ul', 'ol', 'paragraph']],
          ['height', ['height']],
          ['table', ['table']],
          ['insert', ['link', 'picture', 'hr']],
          ['view', ['fullscreen', 'codeview']],
          ['help', ['help']],
          ['misc', ['codeview']],
        ],
         height:230,                
    });          
</script>
<script type="text/javascript">
    
     $(".num").keypress(function (evt) {
     var charCode = (evt.which) ? evt.which : evt.keyCode;
      if (charCode != 46 &&  charCode > 31 &&  (charCode < 48 || charCode > 57)) {
             $('.error2').text('Only Numeric value Insert');
             return false;
    }
    $('.error2').text('');
    return true;
 });
</script>



<?php
$this->load->view('backend_message');
?>

</body>
</html>