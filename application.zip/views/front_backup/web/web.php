
<?php
$this->load->view('front/header/header.php');
?>
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/web.css">
    
  </head>
  <body>

<!-- Web -->
<div class="container-fluid current-profile demands ">
	<div class="col-lg-12 custom-padding d-inline-block">
		<div class="row">
			<div class="col-lg-6 d-inline-block upload-img text-center p-0">
				<img class="img-fluid none-lg" src="assets/image_stdnt1.png">
			</div>
			<div class="col-lg-6 student-info d-inline-block float-right ">
				<h1 class="d-inline-block">Alicia Martin</h1>
				<div class="d-inline-block custom-set">
					<img src="<?=base_url()?>assets/assets/success.png">
					<span>9:41</span>
					<small>Monday,13 June</small>
				</div>
				<form class="custom-css-form">
					<div class="form-group">
						<img src="<?=base_url()?>assets/assets/user.png"><label>Type:</label><span>Regular</span>
					</div>
					<div class="form-group">
						<img src="<?=base_url()?>assets/assets/ranking.png"><label>Level of Student:</label><span>Primary</span>
					</div>
					<div class="form-group">
						<img src="<?=base_url()?>assets/assets/graduation-cap.png"><label>Subject:</label><span>Math</span>

					</div>
					<div class="form-group">
						<img src="<?=base_url()?>assets/assets/clock.png"><label>Date Joined: 15/Dec/2019 11:40am </label>
					</div>
				</form>

				<div class="col-lg-2 d-inline-block p-0">
					<h4>Demands</h4>
				</div>
				<div class="col-lg-10 d-inline-block float-right">
					<form class="form-group p-css">
						<p>It’s windy. The cool breeze of the ocean. It gives, a sense of beauty, in motion. All is flowing, rushing and tide-And I sit in wonder, dreaming beside.
It’s windy. The cool breeze of the ocean. It gives, a sense of beauty, in motion. All is flowing, rushing and tide-And I sit in wonder, dreaming beside.
It’s windy. The cool breeze of the ocean. It gives, a sense of beauty, in motion. All is flowing, rushing and tide-And I sit in wonder, dreaming beside.
It’s windy. The cool breeze of the ocean. It gives, a sense of beauty, in motion. All is flowing, rushing and tide-And I sit in wonder, dreaming beside.
It’s windy. The cool breeze of the ocean. It gives, a sense of beauty, in motion. All is flowing, rushing and tide-And I sit in wonder, dreaming beside.</p>
					</form>
				</div>
				<div class="demand-info">
					<form class="form-inline d-inline-block">
					<label for="pwd" class="mr-sm-2 custom-family d-inline-block">Rate per Hour</label>
					<h3 class="d-inline-block">15$</h3>
					</form>
				</div>
				<div class="col-lg-10 float-right btn-custom text-center d-inline-block">
					<button>Send Offer</button>
				</div>
				</div>
			</div>
	</div>
	
  </body>
</html>