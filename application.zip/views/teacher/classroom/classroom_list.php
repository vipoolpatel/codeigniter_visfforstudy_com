<?php 
    $this->load->view('teacher/header/header');
   $this->load->view('teacher/header/menu');
?>


 <div class="header-spacer"></div>
      <div class="conty">
        <div class="os-tabs-w menu-shad">
          <div class="os-tabs-controls">
            <ul class="navs navs-tabs upper">
              <li class="navs-item">
                <a class="navs-links active" href="<?=base_url()?>teacher/classroom"><i class="os-icon picons-thin-icon-thin-0017_office_archive"></i><span>Class Room</span></a>
              </li>
             
            </ul>
          </div>
        </div><br>
        <div class="all-wrapper no-padding-content solid-bg-all">
            <div class="layout-w">
                <div class="content-w">
                    <div class="content-i">
                        <div class="container-fluid">
                            <div class="row">
                            	 <div class="col-sm-4">
                                    <div class="element-box lined-primary shadow" style="border-radius:10px;">
                                        <h4 class="form-header" style="text-align: center;">Tim Barton 1</h4><br>
                                        <form action="" enctype="multipart/form-data" method="post">
                                            <div class="row">  
                                              <div class="col-sm-12">
                                                    <center><img src="<?=base_url()?>backed/uploads/course/1.jpg" style="width:200px;"></center>
                                                    <hr>
                                                 
                                                </div>
                                                 <div class="col-sm-6"> 
                                                    <div class="form-group label-floating">
                                                        
                                                     
														<b>Class start at :</b>
                                                        <span class="material-input"></span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6"> 
                                                    <div class="form-group label-floating">
                                                      
                                                     <button class="send-btn float-right btn btn-info" style="border-radius: 30px;padding: 5px;font-size: 10px;">Send Message</button>
                                                        <span class="material-input"></span>
                                                        
                                                    </div>
                                                </div>

                                                <div class="col-sm-6"> 
                                                    <div class="form-group label-floating">
                                                        
                                                     
														Time : 33:22:01 Date: 03/03/20 :
                                                        <span class="material-input"></span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6"> 
                                                    <div class="form-group label-floating">
                                                      
 <button class="send-btn float-right btn btn-success" style="border-radius: 30px;padding: 5px;font-size: 10px;">Enter Classroom</button>
                                                        <span class="material-input"></span>
                                                        
                                                    </div>
                                                </div>
 
                                                 <div class="col-sm-6"> 
                                                    <div class="form-group label-floating">
                                                        
                                                     
														<b>Status :</b>
                                                        <span class="material-input"></span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6"> 
                                                    <div class="form-group label-floating">
                                                      
  <button class="send-btn float-right btn btn-orange" style="border-radius: 30px;padding: 5px;font-size: 10px; margin-left: 5px;"> Cancel</button>
 <button class="send-btn float-right btn btn-info" style="border-radius: 30px;padding: 5px;font-size: 10px;">Pending</button>
                                                        <span class="material-input"></span>
                                                        
                                                    </div>
                                                </div>
                                                 
                                                 
                                                
                                                <div class="col-sm-12"> 
                                                    <div class="form-group label-floating">
                                                        <label class="control-label">Write Review :</label>
                                                        <textarea class="form-control" name="front_description_2" rows="5" required="">
                                                        	
                                                        </textarea>
                                                        <span class="material-input"></span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12"> 
                                                    <div>
                                                        <button class="btn btn-primary btn-rounded" type="submit"> Update</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form> 
                                    </div>
                                </div>
                               
                                <div class="col-sm-4">
                                    <div class="element-box lined-primary shadow" style="border-radius:10px;">
                                        <h4 class="form-header" style="text-align: center;">Tim Barton 2</h4><br>
                                        <form action="" enctype="multipart/form-data" method="post">
                                            <div class="row">  
                                              <div class="col-sm-12">
                                                    <center><img src="<?=base_url()?>backed/uploads/course/2.jpg" style="width:200px;"></center>
                                                    <hr>
                                                 
                                                </div>
                                                 <div class="col-sm-6"> 
                                                    <div class="form-group label-floating">
                                                        
                                                     
														<b>Class start at :</b>
                                                        <span class="material-input"></span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6"> 
                                                    <div class="form-group label-floating">
                                                      
 <button class="send-btn float-right btn btn-info" style="border-radius: 30px;padding: 5px;font-size: 10px;">Send Message</button>
                                                        <span class="material-input"></span>
                                                        
                                                    </div>
                                                </div>

                                                <div class="col-sm-6"> 
                                                    <div class="form-group label-floating">
                                                        
                                                     
														Time : 33:22:01 Date: 03/03/20 :
                                                        <span class="material-input"></span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6"> 
                                                    <div class="form-group label-floating">
                                                      
 <button class="send-btn float-right btn btn-success" style="border-radius: 30px;padding: 5px;font-size: 10px;">Enter Classroom</button>
                                                        <span class="material-input"></span>
                                                        
                                                    </div>
                                                </div>
 
                                                 <div class="col-sm-6"> 
                                                    <div class="form-group label-floating">
                                                        
                                                     
														<b>Status :</b>
                                                        <span class="material-input"></span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6"> 
                                                    <div class="form-group label-floating">
                                                      
  <button class="send-btn float-right btn btn-orange" style="border-radius: 30px;padding: 5px;font-size: 10px; margin-left: 5px;"> Cancel</button>
 <button class="send-btn float-right btn btn-info" style="border-radius: 30px;padding: 5px;font-size: 10px;">Pending</button>
                                                        <span class="material-input"></span>
                                                        
                                                    </div>
                                                </div>
                                                 
                                                 
                                                
                                                <div class="col-sm-12"> 
                                                    <div class="form-group label-floating">
                                                        <label class="control-label">Write Review :</label>
                                                        <textarea class="form-control" name="front_description_2" rows="5" required="">
                                                        	
                                                        </textarea>
                                                        <span class="material-input"></span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12"> 
                                                    <div>
                                                        <button class="btn btn-primary btn-rounded" type="submit"> Update</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form> 
                                    </div>
                                </div>
                                
                                 <div class="col-sm-4">
                                    <div class="element-box lined-primary shadow" style="border-radius:10px;">
                                        <h4 class="form-header" style="text-align: center;">Tim Barton 3</h4><br>
                                        <form action="" enctype="multipart/form-data" method="post">
                                            <div class="row">  
                                              <div class="col-sm-12">
                                                    <center><img src="<?=base_url()?>backed/uploads/course/1.jpg" style="width:200px;"></center>
                                                    <hr>
                                                 
                                                </div>
                                                 <div class="col-sm-6"> 
                                                    <div class="form-group label-floating">
                                                        
                                                     
														<b>Class start at :</b>
                                                        <span class="material-input"></span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6"> 
                                                    <div class="form-group label-floating">
                                                      
 <button class="send-btn float-right btn btn-info" style="border-radius: 30px;padding: 5px;font-size: 10px;">Send Message</button>
                                                        <span class="material-input"></span>
                                                        
                                                    </div>
                                                </div>

                                                <div class="col-sm-6"> 
                                                    <div class="form-group label-floating">
                                                        
                                                     
														Time : 33:22:01 Date: 03/03/20 :
                                                        <span class="material-input"></span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6"> 
                                                    <div class="form-group label-floating">
                                                      
 <button class="send-btn float-right btn btn-success" style="border-radius: 30px;padding: 5px;font-size: 10px;">Enter Classroom</button>
                                                        <span class="material-input"></span>
                                                        
                                                    </div>
                                                </div>
 
                                                 <div class="col-sm-6"> 
                                                    <div class="form-group label-floating">
                                                        
                                                     
														<b>Status :</b>
                                                        <span class="material-input"></span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6"> 
                                                    <div class="form-group label-floating">
                                                      
 <button class="send-btn float-right btn btn-orange" style="border-radius: 30px;padding: 5px;font-size: 10px; margin-left: 5px;"> Cancel</button>
 <button class="send-btn float-right btn btn-info" style="border-radius: 30px;padding: 5px;font-size: 10px;">Pending</button>
                                                        <span class="material-input"></span>
                                                        
                                                    </div>
                                                </div>
                                                 
                                                 
                                                
                                                <div class="col-sm-12"> 
                                                    <div class="form-group label-floating">
                                                        <label class="control-label">Write Review :</label>
                                                        <textarea class="form-control" name="front_description_2" rows="5" required="">
                                                        	
                                                        </textarea>
                                                        <span class="material-input"></span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12"> 
                                                    <div>
                                                        <button class="btn btn-primary btn-rounded" type="submit"> Update</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form> 
                                    </div>
                                </div>

                            </div>
                           
                           
                        </div>
                    </div>
                </div>
                <div class="display-type"></div>
            </div>
        </div>
    </div>
</div>      </div>
      <div class="display-type"></div>
    </div>



<?php 
    $this->load->view('teacher/header/footer');
?>
